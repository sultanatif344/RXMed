export class Fta {
    id: number;
    rxcui: number;
    proprietaryName: string;
    nonProprietaryName: string;
    excludedDrugsBack: string;
    tty: string;
    relatedDrugs: [number];
    sbd: [number];
    scd: [number];
}
