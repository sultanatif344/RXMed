export const environment = {
  production: true,
  apiUrl: 'https://rxmedapi.azurewebsites.net/api/v1'
};
